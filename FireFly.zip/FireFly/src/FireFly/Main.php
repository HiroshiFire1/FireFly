<?php
namespace:FireFly
use: pocketmine/plugin/pluginBase:
use: pocketmine/command/Command;
use: pocketmine/command/CommandSender;
use: pocketmine/event/Listener;
// Player
use: pocketmine/Player; 
// Clase
clash Main extends PluginBase implements Listener
public function onCommand(CommandSender $sender
Command $cmd, string $label, array $args) :
bool{
	switch($cmd->getname()){
		
case:"FireFly"
if(!isset($args[0])){
	$sender->sendMenssage("§cUse /firefly on\off");
return false;
}
if($args[0] == "on"){
	$sender->setAllowFlight(true);
	$sender->sendMessage("§4 Your Flight Mode Has Been Activated");
	$sender->addTitle("§bON");
	}
	if($args[0] == "off"
	$sender->setAllowFlight(false);
	$sender->setFlying(false);
	$sender->sendMessage("§d Your Flight Mode Has Been Desactivate");
	$sender->addTitle("§cOFF");
	}
	}
	return true;
	}
	}